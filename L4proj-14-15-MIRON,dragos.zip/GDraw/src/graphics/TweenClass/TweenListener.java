package graphics.TweenClass;

public interface TweenListener {
	public abstract void tweenCompleted(TweenEvent event);
}